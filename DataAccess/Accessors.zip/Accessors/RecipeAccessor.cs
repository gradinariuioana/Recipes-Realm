﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelAccessDate_DBFirst
{
    public class RecipeAccessor
    {
        public static void ShowRecipes()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Recipes ---");

                var recipes = context.Recipes.ToList();
                foreach (Repository_DBFirst.Recipe item in recipes)
                {
                    Console.WriteLine("Recipe Name: {0}\nRecipe Description: {1}\nCooking Time: {2}, Difficulty Level: {3} \n\n", 
                                       item.Recipe_Name, item.Recipe_Description, item.Cooking_Time, item.Difficulty_Level);
                }
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipe = context.Recipes.AsNoTracking().FirstOrDefault(r => r.Recipe_ID == idx);
                return recipe.Recipe_Name;
            }
        }
    }
}
