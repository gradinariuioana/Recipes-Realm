﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class RecipeStepAccessor
    {
        public static void ShowRecipeSteps()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Recipe Steps ---");

                var recipeSteps = context.RecipeSteps.Include(r => r.Recipe).ToList();
                foreach (Repository_DBFirst.RecipeStep item in recipeSteps)
                {
                    Console.WriteLine("Recipe Name: {0}\nStep Number: {1}\nStep Description: {2}\n\n",
                                       item.Recipe.Recipe_Name, item.Step_Number, item.Step_Description);
                }
            }
        }

        public static string GetRecipeStepTitle(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeStep = context.RecipeSteps.AsNoTracking().FirstOrDefault(r => r.Step_ID == idx);
                return recipeStep.Step_Title;
            }
        }
    }
}
