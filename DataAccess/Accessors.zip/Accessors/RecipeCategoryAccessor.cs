﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class RecipeCategoryAccessor
    {
        public static void ShowRecipeCategories()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Recipe Categories ---");

                var recipeCategories = context.RecipeCategories.Include(r => r.Recipe).Include(r => r.Category).ToList();
                foreach (Repository_DBFirst.RecipeCategory item in recipeCategories) 
                { 
                    Console.WriteLine("Recipe Name: {0}\nCategory Name: {1}\n\n", 
                                       item.Recipe.Recipe_Name, item.Category.Category_Name);
                }
            }
        }

        public static string GetCategoryName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeCategory = context.RecipeCategories.Include(r => r.Category).FirstOrDefault(r => r.Category_ID == idx);
                return recipeCategory.Category.Category_Name;
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeCategory = context.RecipeCategories.Include(r => r.Recipe).FirstOrDefault(r => r.Category_ID == idx);
                return recipeCategory.Recipe.Recipe_Name;
            }
        }
    }
}
