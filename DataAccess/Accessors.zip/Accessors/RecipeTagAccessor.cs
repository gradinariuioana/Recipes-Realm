﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class RecipeTagAccessor
    {
        public static void ShowRecipeTags()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Recipe Tags ---");

                var recipeTags = context.RecipeTags.Include(r => r.Recipe).Include(r => r.Tag).ToList();
                foreach (Repository_DBFirst.RecipeTag item in recipeTags) 
                { 
                    Console.WriteLine("Recipe Name: {0}\nTag Name: {1}\n\n", 
                                       item.Recipe.Recipe_Name, item.Tag.Tag_Name);
                }
            }
        }

        public static string GetTagName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeTag = context.RecipeTags.Include(r => r.Tag).FirstOrDefault(r => r.Tag_ID == idx);
                return recipeTag.Tag.Tag_Name;
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeTag = context.RecipeTags.Include(r => r.Recipe).FirstOrDefault(r => r.Tag_ID == idx);
                return recipeTag.Recipe.Recipe_Name;
            }
        }
    }
}
