﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class RecipeIngredientAccessor
    {
        public static void ShowRecipeIngredients()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Recipe Ingredients ---");

                var recipeIngredients = context.RecipeIngredients.Include(r => r.Recipe).Include(r => r.Ingredient).ToList();
                foreach (Repository_DBFirst.RecipeIngredient item in recipeIngredients)
                {
                    Console.WriteLine("Recipe Name: {0}\nIngredient Name:{1}\nIngredient Quantity: {2}{3}\n\n",
                                       item.Recipe.Recipe_Name, item.Ingredient.Ingredient_Name, item.Quantity, item.Measurement_Unit);
                }
            }
        }

        public static string GetIngredientName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeIngredient = context.RecipeIngredients.Include(r => r.Ingredient).FirstOrDefault(r => r.ID == idx);
                return recipeIngredient.Ingredient.Ingredient_Name;
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var recipeIngredient = context.RecipeIngredients.Include(r => r.Recipe).FirstOrDefault(r => r.ID == idx);
                return recipeIngredient.Recipe.Recipe_Name;
            }
        }
    }
}
