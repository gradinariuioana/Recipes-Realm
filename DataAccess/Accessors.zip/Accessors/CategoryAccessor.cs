﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelAccessDate_DBFirst
{
    public class CategoryAccessor
    {
        public static void ShowCategories()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Categories ---");

                var categorys = context.Categories.ToList();
                foreach (Repository_DBFirst.Category item in categorys)
                {
                    Console.WriteLine("Category Name: {0}, Category Description: {1}", item.Category_Name, item.Category_Description);
                }
            }
        }

        public static string GetCategoryName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var category = context.Categories.FirstOrDefault(c => c.Category_ID == idx);
                return category.Category_Name;
            }
        }
    }
}
