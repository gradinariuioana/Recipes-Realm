﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class ReviewAccessor
    {
        public static void ShowReviews()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Reviews ---");

                var reviews = context.Reviews.Include(r => r.Recipe).Include(r => r.User).ToList();
                foreach (Repository_DBFirst.Review item in reviews)
                {
                    Console.WriteLine("User Name: {0}\nReview Text: {1}\nReview Date: {2}\nRecipe Name: {3}\n\n", 
                                       item.User.User_Name, item.Review_Text, item.Review_Date.ToString("dd-MM-yyyy"), item.Recipe.Recipe_Name);
                }
            }
        }

        public static string GetUserName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var review = context.Reviews.Include(r => r.User).FirstOrDefault(r => r.Review_ID == idx);
                return review.User.User_Name;
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var review = context.Reviews.Include(r => r.Recipe).FirstOrDefault(r => r.Review_ID == idx);
                return review.Recipe.Recipe_Name;
            }
        }
    }
}
