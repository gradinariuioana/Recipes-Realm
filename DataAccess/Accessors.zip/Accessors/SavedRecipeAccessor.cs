﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NivelAccessDate_DBFirst
{
    public class SavedRecipeAccessor
    {
        public static void ShowSavedRecipes()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- SavedRecipes ---");

                var savedRecipes = context.SavedRecipes.Include(s => s.Recipe).Include(s => s.User).ToList();
                foreach (Repository_DBFirst.SavedRecipe item in savedRecipes)
                {
                    Console.WriteLine("User Name: {0}\nSaving Date: {1}\nRecipe Name: {2}\n\n", 
                                       item.User.User_Name, item.Saving_Date.ToString("dd-MM-yyyy"), item.Recipe.Recipe_Name);
                }
            }
        }

        public static string GetUserName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var savedRecipe = context.SavedRecipes.Include(s => s.User).FirstOrDefault(s => s.ID == idx);
                return savedRecipe.User.User_Name;
            }
        }

        public static string GetRecipeName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var savedRecipe = context.SavedRecipes.Include(s => s.Recipe).FirstOrDefault(s => s.ID == idx);
                return savedRecipe.Recipe.Recipe_Name;
            }
        }
    }
}
