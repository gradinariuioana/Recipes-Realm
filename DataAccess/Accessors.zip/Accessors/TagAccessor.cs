﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NivelAccessDate_DBFirst
{
    public class TagAccessor
    {
        public static void ShowTags()
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                Console.WriteLine("--- Tags ---");

                var tags = context.Tags.ToList();
                foreach (Repository_DBFirst.Tag item in tags)
                {
                    Console.WriteLine("Tag Name: {0}", 
                                       item.Tag_Name);
                }
            }
        }

        public static string GetTagName(int idx)
        {
            using (var context = new Repository_DBFirst.RecipesRealmEntities())
            {
                var tag = context.Tags.FirstOrDefault(t => t.Tag_ID == idx);
                return tag.Tag_Name;
            }
        }
    }
}
